=== HaberEditoru.com Haber Botu ===
Contributors: mtalmac
Donate link: http://www.habereditoru.com
Tags: Haber Botu, HaberEditoru, HaberEditörü.com, içerik bot, news bot
Requires at least: 3.6
Tested up to: 4.5
Stable tag: 1.0
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Haber Botu; Haber ajansları veya diğer sitelerden topladığı haberleri web sitenize otomatik olarak ekleyen bir haber botudur.

== Description ==

**Haber Editörü Nedir?**

HaberEditoru.com Haber Botu abone olduğunuz haber ajanslarından veya çeşitli haber kaynaklarını derleyerek topladığı haber ve içerikleri web sitenize otomatik olarak ekleyen akıllı bir bot sistemidir. Abonelik paketinize göre belirli periyotlarda haber kaynaklarını tarayarak siteniz için uygun yeni içerikleri bulup web sitenize otomatik olarak ekler.

Haber Botları içerik ile ilişkili resimleri, videoları ve diğer dosyaları sunucunuza kayıt edebilir, videoları özel embed kodlarınız ile haber metnine ekleyebilir.

**Bot Editörler**

Kontrol panel aracılığı ile abonelik paketinizin kapasitesine göre Bot editörler tanımlayabilirsiniz. 
Tanımladığınız Bot editörler belirli periyotlarda haber kaynaklarını tarayarak web siteniz için uygun içerikleri bulur ve ekler. 
Bot Editör için çeşitli filtreler tanımlayarak ilgili içerikleri bulur, belirlediğiniz kullanıcı adı ile belirlediğiniz kategoriye içerik eklemesi yapar. 
Bot editörler hakkında [detaylı bilgi için buraya tıklayınız.](http://habereditoru.com/robot-editorler.html "Bot Editörler")

**Tekrarlayan haberler eklenmez**

Bot editörler haber eklerken aynı içeriğin daha önce eklenip eklenmediğini kontrol ederek sadece sitenizde olmayan içerikleri ekler. 
Dolayısıyla hem robot editörünüz hem de sizin mevcut editörleriniz aynı anda çalışabilir.

**Sosyal Habercilik**

Facebook, Twitter vs gibi sosyal paylaşım sistelerinde web sitenizin hesabı varsa eklenen içerikler otomatik olarak bu platformlarda paylaşılabilir.

**Pingleme Servisleri**

Yeni yayınlanan ve güncellenen içeriklerin arama motorlarında listelenmesini hızlandırmak için ping atma yöntemi kullanılır. 
ing atma basit bir şekilde arama motorlarına haber gönderilerek botların siteye gelmesi sağlanılır ve siteye eklenen yeni içeriklerin ve güncellenmiş olan içeriklerin bir an önce arama motorlarında listelenmesini sağlanır. 
HaberEditörü sistemi sitenize eklenen tüm içerikler için Pingleme servislerini uyararak arama motorlarının sitenizi çok çabuk bir şekilde ziyaret etmesini sağlar.

== Installation ==

1. Upload `HaberEditoru` plug-in to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress

Plugin's page sits left and top admin bar.

== Frequently Asked Questions ==

**Haber Ajansına üye değilim, olmam gerekiyor mu?**

Hangi haber ajanslarının haberlerini kullanmak istiyorsanız ilgili haber ajansına yasal olarak abone olmanız gerekmektedir. 
Bir haber ajansının haberlerini yetkisiz ve izinsiz kullanmak yasal olarak suç olup bu konuda çok hassas davranmanız gerekmektedir. 

[Daha Fazlası](http://habereditoru.com/faq.html)

== Screenshots ==

1. Bot Manage
2. Content Sources
3. Matching Categories
4. Activities
5. Subscription and Payment 

1. Plugin control panel

== Changelog ==

= 1.0 =
Plugin relase

== Upgrade Notice ==

-